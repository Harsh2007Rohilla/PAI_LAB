from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

model      = pickle.load(open('sentiment_model.pkl', 'rb'))
vectorizer = pickle.load(open('tfidf_vectorizer.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    review_text = request.form.get('review_text', '').strip()

    if not review_text:
        return render_template('index.html', error="Please enter a movie review.")

    vectorized  = vectorizer.transform([review_text])
    prediction  = model.predict(vectorized)[0]
    probability = model.predict_proba(vectorized)[0]

    label       = "POSITIVE" if prediction == 1 else "NEGATIVE"
    confidence  = round(max(probability) * 100, 1)
    is_positive = prediction == 1

    return render_template('index.html',
        label=label, confidence=confidence,
        is_positive=is_positive, review_text=review_text
    )

if __name__ == '__main__':
    app.run(debug=True)
