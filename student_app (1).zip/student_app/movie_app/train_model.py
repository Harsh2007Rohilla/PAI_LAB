import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pickle
data = {
    'review': [
        "Awesome movie!", "Great acting.", "Best movie ever.", "I loved it!", 
        "Terrible film.", "So boring.", "Bad direction.", "Worst movie ever.", 
        "I hated this movie", "Waste of money", "Not good at all"
    ],
    'label': [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0] 
}

data = {
    'review': ["Awesome movie!", "Terrible film.", "Great acting.", "So boring.", "Best movie ever.", "Bad direction."],
    'label': [1, 0, 1, 0, 1, 0] 
}
df = pd.DataFrame(data)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['review'])
y = df['label']

model = LogisticRegression()
model.fit(X, y)

pickle.dump(model, open('sentiment_model.pkl', 'wb'))
pickle.dump(vectorizer, open('tfidf_vectorizer.pkl', 'wb'))
print("Models created successfully!")
