import os

# 1. Main folder aur templates folder banana
os.makedirs("movie_app/templates", exist_ok=True)

# 2. app.py ka code
app_code = """from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

model      = pickle.load(open('sentiment_model.pkl', 'rb'))
vectorizer = pickle.load(open('tfidf_vectorizer.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    review_text = request.form.get('review_text', '').strip()

    if not review_text:
        return render_template('index.html', error="Please enter a movie review.")

    vectorized  = vectorizer.transform([review_text])
    prediction  = model.predict(vectorized)[0]
    probability = model.predict_proba(vectorized)[0]

    label       = "POSITIVE" if prediction == 1 else "NEGATIVE"
    confidence  = round(max(probability) * 100, 1)
    is_positive = prediction == 1

    return render_template('index.html',
        label=label, confidence=confidence,
        is_positive=is_positive, review_text=review_text
    )

if __name__ == '__main__':
    app.run(debug=True)
"""

# 3. index.html ka code
html_code = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Review Analyzer</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 500px; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; }
        textarea { width: 100%; padding: 10px; margin-bottom: 10px; }
        button { padding: 10px 20px; background-color: #28a745; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #218838; }
        .error { color: red; }
        .result { margin-top: 20px; padding: 15px; border-radius: 5px; background-color: #f8f9fa; }
        .positive { color: green; font-weight: bold; }
        .negative { color: red; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Movie Review Analyzer 🎬</h2>
    <form action="/predict" method="POST">
        <textarea name="review_text" rows="4" placeholder="Enter movie review here..." required></textarea>
        <button type="submit">Analyze Review</button>
    </form>
    {% if error %} <p class="error">{{ error }}</p> {% endif %}
    {% if label %}
        <div class="result">
            <p><strong>Your Review:</strong> "{{ review_text }}"</p>
            <p><strong>Sentiment:</strong> <span class="{% if is_positive %}positive{% else %}negative{% endif %}">{{ label }}</span></p>
            <p><strong>Confidence:</strong> {{ confidence }}%</p>
        </div>
    {% endif %}
</div>
</body>
</html>
"""

# 4. train_model.py ka code
train_code = """import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pickle

data = {
    'review': ["Awesome movie!", "Terrible film.", "Great acting.", "So boring.", "Best movie ever.", "Bad direction."],
    'label': [1, 0, 1, 0, 1, 0] 
}
df = pd.DataFrame(data)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['review'])
y = df['label']

model = LogisticRegression()
model.fit(X, y)

pickle.dump(model, open('sentiment_model.pkl', 'wb'))
pickle.dump(vectorizer, open('tfidf_vectorizer.pkl', 'wb'))
print("Models created successfully!")
"""

# 5. Files generate karna
with open("movie_app/app.py", "w", encoding="utf-8") as f:
    f.write(app_code)

with open("movie_app/templates/index.html", "w", encoding="utf-8") as f:
    f.write(html_code)

with open("movie_app/train_model.py", "w", encoding="utf-8") as f:
    f.write(train_code)

print("✅ 'movie_app' folder aur uske andar ki saari files ban gayi hain!")
print("👉 Ab 'cd movie_app' type karein aur uske baad 'python train_model.py' run karein.")